package net.eyeserve.projects;

public class Kinetype {
	
	//creates an instance of kinetypeGUI in a static manner so that it can be
	//referred to from any class
	public static KinetypeGUI kinetypeGUI;
	
	public static void main(String[] args)
	{
		//defines that instance
		kinetypeGUI = new KinetypeGUI();
	}
}
